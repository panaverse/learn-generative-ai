def my_first_function()->str:
    return "Hello World"

result: str = my_first_function()

print(result)